import java.util.Scanner;


public class Q1 {
	public static void main(String[] args) {
		
		Scanner reader = new Scanner(System.in);
		System.out.println("Enter the shipper number: ");
		int shipper = reader.nextInt();
		double weight;
		//double weight = 1.0;
		double shippingCost; 
		//shippingCost = weight * 0.5;
		
		if (shipper == 2) {
			System.out.println("Enter the weight: ");
			weight= reader.nextDouble();
			reader.close();
			shippingCost = weight * 0.3;
			if (weight > 1.0 && weight < 1.75) {
				shippingCost = shippingCost + 2;
				if (weight > 1.75) {
					shippingCost = shippingCost + 3;
				}
			} else {
				System.out.println("DHL ShippingCost: " + shippingCost);
			}
			System.out.println("DHL ShippingCost: " + shippingCost);
		} else if (shipper == 1) {
			System.out.println("Enter the weight: ");
			weight= reader.nextDouble();
			reader.close();
			shippingCost = weight * 0.48;
			if (weight > 1.3) {
				shippingCost = shippingCost + 2.1;
			} else {
				System.out.println("We didn't get it! " + shippingCost);
			}
			System.out.println("FedEx ShippingCost: " + shippingCost);
		} 
		else if (shipper == 0) {
			System.out.println("Enter the weight: ");
			weight= reader.nextDouble();
			reader.close();
			shippingCost = weight * 0.5;
			if (weight > 1.5) {
				shippingCost = shippingCost + 2.0;
			} else {
				System.out.println("We didn't get!  " + shippingCost);
			}
			System.out.println("UPS ShippingCost: " + shippingCost);
		} 
		else {
			System.out.println("Sorry the system cannot calculated ");
		}
	}
}
