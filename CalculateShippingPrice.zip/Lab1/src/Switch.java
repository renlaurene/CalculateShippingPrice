
public class Switch {

	public static void main(String[] args) {
        int shipper = 1;
        double weight = 1.0;
        double shippingCost = 0.0;
        final int UPS = 0;
        final int FEDEX = 1;
        final int DHL = 2;
        
        switch (shipper){
        case UPS:
        	shippingCost = weight * 0.5;
        	if (weight > 1.6){
        		shippingCost = shippingCost + 2.0;
        	}
        	break;
        case FEDEX:
            shippingCost = weight * 0.48;
		    if (weight > 1.3) {
		    	shippingCost = shippingCost + 2.1;
		    }
            break; 
        case DHL: 
             shippingCost = weight * 0.3;
		       if (weight > 1.0 && weight < 1.75) {
			      shippingCost = shippingCost + 2;
			      if (weight > 1.75) {
			    	  shippingCost = shippingCost + 3;
			      }
		       }
			   break;
		 
        default:
        	System.out.println("Don't know to compute the cost");
        	break;
        	
        }
		
	}

}
